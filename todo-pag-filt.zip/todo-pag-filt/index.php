<?php 
include 'lib/task.php';
$tasks=load_tasks();// functia trebuie sa aiba RETURN


?>

<!-- // afisare -->
<?php
//logica-sablon-baza de date
include 'templates(sabloane)/task-list.php';
include 'templates(sabloane)/task-form.php';


?>
