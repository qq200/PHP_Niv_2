<?php 
include 'config.php';
include 'lib/task.php';
include 'lib/load_people.php';
$tasks=load_tasks(false);// functia trebuie sa aiba RETURN
$people=load_people();

?>

<!-- // afisare -->
<?php
//logica-sablon-baza de date
include 'templates(sabloane)/task-list.php';
include 'templates(sabloane)/task-form.php';


?>
