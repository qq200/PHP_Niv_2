<?php
$product=[
    [
        "name"=>"Product1",
        "price"=>10000
    ],
    [
        "name"=>"Product2",
        "price"=>1000
    ],
    [
        "name"=>"Product3",
        "price"=>5000
    ]
];
$prices=array_column($product, "price");
array_multisort($prices, $product);
var_dump($product);
?>

<!-- ACASA de sortat dupa vechimea datii -->