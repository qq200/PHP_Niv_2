<?php

?>

<form action="save.php" method="POST">
    <input name="title" type="text" placeholder="task title">
    <?php include 'templates(sabloane)/people-select.php' ?>
    <hr>
    <button>Save</button>

</form>