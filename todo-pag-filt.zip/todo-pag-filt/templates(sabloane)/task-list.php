<?php
//sablonul listei de cerinte

?>
<div>
    <h3>Showing tasks (<?php print count($tasks)?>)</h3>
    <ul>
        <?php foreach($tasks as $task){?>
        <li>        
        <input type="checkbox" <?php if($task["status"]=="done"){?> checked <?php }?>>
        <?php  print $task["title"]; ?>
        <small>
        (<?php  
        $t=round((strtotime ($task['created']))/60/60/24);//cite secunde din 1970
        $now = round(time()/60/60/24) ;//secunde la moment
        $dt =($now-$t);//diferenta in zile
         
        if($dt <=1){print "today" ; } else 
        if($dt ==2){  print "yesterday"; } else
        if($dt <=7 and $dt >2){ print "this week";} else 
        if ($dt <30 and $dt >7){ print "this month";} else 
        if($dt >=30){print "this year";}
        ?>)
        </small>
        </li>        
        <?php }?>
    </ul>

</div>
<!-- //ACASA!!  history--today,yesterday, this week, this month, this year -->