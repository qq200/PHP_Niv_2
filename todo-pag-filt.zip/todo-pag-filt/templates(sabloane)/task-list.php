<?php
//sablonul listei de cerinte

?>
<div>
    <h3>Showing tasks (<?php print count($tasks)?>)</h3>
    <ul>
        <?php foreach($tasks as $task){ ?>
        <li>        
        <input type="checkbox" 
        <?php if($task['status']=='done'){?>checked <?php }?>>
        <? print $task['title'] ?>
        <small><? print $task['created'] 
        
        //ACASA!!  history--today,yesterday, this week, this month, this year
        ?></small>
        </li>
        
        <?php }?>
    </ul>

</div>