<select name="" id="">
    <option value="">Valea</option>
    <option value="">Ivanusca</option>

<!-- acasa 2!! inca un lib  load_people; include lib, foreach-templates-->

</select>