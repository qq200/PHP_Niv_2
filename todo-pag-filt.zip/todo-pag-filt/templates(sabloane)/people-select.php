<select name="" id="">
<?php foreach($people as $select){?>
    <option value=""><?php print $select["name"] ?> (<?php print $select["job"] ?>)</option>
    
<?php }?>

<!-- acasa 2!! inca un lib  load_people; include lib, foreach-templates-->

</select>