<?php
include 'lib/task.php';
    $task=[
        'title'=>$_POST['title'],
        'status'=>'new',
        'created'=> date('Y-m-d')
    ];

    save_task($task);
   
    
?>