<?php

const PER_PAGE=5; ///cite tascuri sa apara pe foaie



?>