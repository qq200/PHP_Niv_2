<?php
// phpinfo();
//graphic library GD/Iamgick
//composer- intervention/immage

//images 1.jpg(600x400)->php-> 2.jpg(100x100)
//1- load the image:
$original_image=imagecreatefromjpeg("images/1.jpeg");
//2- create new image 100x100
$new_image=imagecreate(100,100);
//3- copy&resize
imagecopyresized(
    $new_image,
    $original_image,
    0,0,
    0,0,
    100,100,
    600,400
);

//5- save
imagejpeg($new_image,"images/2.jpg", 50);
?>
<img src="images/2.jpg"/>