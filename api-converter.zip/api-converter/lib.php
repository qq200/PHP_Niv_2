<?php
//aici se formeaza functiile

function welcome(){
    print "<h1>Welcome</h1>";
}
function getFixerData(){ ///se va conecta la fixer si va citi datele
    global $config;/// VARIABILA DIN CONFIG.php -functia nu vede variabila daca nu e declarata in functie
    //raspuns in format string-Json
   
    $response=file_get_contents("http://data.fixer.io/api/latest?access_key=".$config['ACCES_KEY']);
    // var_dump($response);
    //decodarea
    $data=json_decode($response, true);//>> in masiv transforma datele nu in obiect cu TRUE
    // var_dump($data);
    //scoaterea datelor din functie
    return $data;
} 
function saveData($data){
    $today=date("Y-m-d");
    $ser  =serialize($data); // in format compact php, mai rapid ca JSON
    file_put_contents("database/$today.txt",$ser);
}
function loadData(){
    $today=date("Y-m-d");
    if(file_exists("database/$today.txt")){
        $text=file_get_contents("database/$today.txt");
        $data=unserialize($text);

    }else{ $data=null;}
    return $data;
}
?>