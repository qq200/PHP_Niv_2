<?php
//aici se formeaza functiile
const ACCES_KEY="01f3108e03276a5141b10da71401b2c2"; //acces la API
function welcome(){
    print "<h1>Welcome</h1>";
}
function getFixerData(){ ///se va conecta la fixer si va citi datele
    $response=file_get_contents("
        http://data.fixer.io/api/latest?access_key=".ACCES_KEY

    );
} 

?>