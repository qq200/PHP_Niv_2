<?php
//salvarea configurarii
$config=[
    'ACCES_KEY'=>"01f3108e03276a5141b10da71401b2c2",
    'currencies'=>[
        'MDL',
        'USD',
        'EUR',
        'RON',
        'RUB'
    ],


]

?>
