<?php
// include our library:
include 'config.php';
include 'lib.php';
$amount=$_GET['amount']??0;
$currency=$_GET['key']??0;
welcome();
$data=loadData();//incercam sa gasim failul local
if(!$data){
    $data=getFixerData();
    saveData($data);
}
// getFixerData();
// var_dump($data);
///////ACASA se facut prin GET sa arate suma convertita
?>
<form>
<table border="1px">
    <?php  foreach($config['currencies'] as $key){ ?>
    <tr>
        <td><input type="radio" name="key" value="<?php print $key?>"/></td>
        <td><?php print $key ?></td>
        <td><?php printf('%05.2f', $data['rates']["$key"]);?></td>
    </tr>
    <?php } ?>
    <tr>
        <td colspan="3">
        <?php if($amount==0){ ?>
        <input type="text" name="amount">
        <?php } else {printf ('%05.2f',$amount*$data['rates']["$currency"]); } ?>
        <button>Convert</button>
        </td>   
    
    </tr>


</table>

</form>