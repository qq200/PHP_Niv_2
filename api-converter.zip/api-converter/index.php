<?php
// include our library:
include 'config.php';
include 'lib.php';
welcome();
$data=loadData();//incercam sa gasim failul local
if(!$data){
    $data=getFixerData();
    saveData($data);
}
// getFixerData();
// var_dump($data);
///////ACASA se facut prin GET sa arate suma convertita
?>
<form>
<table border="1px">
    <?php  foreach($config['currencies'] as $key){ ?>
    <tr>
        <td><input type="radio" name="key" value="<?php print $key?>"/></td>
        <td><?php print $key ?></td>
        <td><?php printf('%05.2f', $data['rates']["$key"]);?></td>
    </tr>
    <?php } ?>
    <tr>
        <td colspan="3">
        <input type="text" name="amount">
        <button>Convert</button>
        </td>   
    
    </tr>


</table>

</form>