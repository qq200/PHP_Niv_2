<?php
// include our library:
include 'lib.php';
welcome();
getFixerData();
?>