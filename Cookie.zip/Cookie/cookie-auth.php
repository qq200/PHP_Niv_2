<?php
const USER='admin';
const PASS='12345';

$is_authenticate=$_COOKIE['auth'] ?? false;

$user=$_POST['user']??'';
$pass=$_POST['pass']??'';

if($is_authenticate || ($user == USER and $pass == PASS)){
    print "Welcom " .USER. " ! ";
    $is_authenticate=true;
    setcookie('auth', true, time()+24*3600);
}else{ print "WRONG";}


?>
<?php if(!$is_authenticate){ ?>
    <form method="POST">
    <input name="user" type="text" placeholder="username..."><br>
    <input name="pass" type="text" placeholder="pasword..."><br>
    <button>ENTER</button>
    </form>
<?php } ?>