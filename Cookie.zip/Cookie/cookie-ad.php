<?php
function showAd(){
    print "
    <hr/>
    <marquee>
    <h2> Developer PHP website CHEAP</h2>
    <p> 3 years of experience</p>
    </marquee>
    <hr/>
    ";
    // set info -> browser - sa arate 1 data reclama
    setcookie("seen_ad", true, time()+3600); //ACASA ora locala :local/time/utc_1
    
}
if(!isset($_COOKIE["seen_ad"])){
showAd();
}

?>
<h1>More about COOKIE</h1>
<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptates quia unde eligendi maxime, magni temporibus laboriosam repellendus deserunt blanditiis tempore architecto inventore. Reprehenderit quod eum, perspiciatis ab voluptatibus blanditiis accusantium molestiae. Pariatur totam doloremque deleniti a libero officiis vero iure?</p>