<?php
$v=$_COOKIE['v']??1;



print "you've visits this page $v times!";

setcookie("v", ++$v); //aduna pe urma arata
?>