<?php
var_dump($_SERVER);
$client_ip=$_SERVER["REMOTE_ADDR"];
$client_dta=file_get_contents("http://ip-api.com/csv/$client_ip");
$client_arr=explode(",",$client_dta);
print $client_ip;

?>
