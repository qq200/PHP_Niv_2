<?php
session_start();
// var_dump($_GET);
$r=$_GET['r'];   //citim coordonatele
$c=$_GET['c'];

$map=$_SESSION['map'];

if      ($map[$r][$c]==0){  //daca in coordonate se afta corabie atunci shoot, daca nu miss
        $map[$r][$c]=2; 
}else if($map[$r][$c]==1){
        $map[$r][$c]=3;
}
$_SESSION['map']=$map;  // salvam modificarile in session si redirectional pe map.php
header("location: map.php")
?>