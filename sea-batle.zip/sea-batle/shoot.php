// switch($j){ 
        //     case 0:?><img src="icons/water.png" ><?php ; break;
        //     case 1:?><img src="icons/ship.png"  ><?php ; break;
        //     case 2:?><img src="icons/miss.png"  ><?php ; break;
        //     case 3:?><img src="icons/explosion.png"><?php; break;            
        //     // default: print "wrong"; break;
        // }