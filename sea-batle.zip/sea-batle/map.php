<?php
session_start();

//0-water
//1-ship
//2-miss
//3-hit YEEE
$map=$_SESSION['map'] ??   //daca nu este in session o scrie din nou
[
    [3,1,0,0,2,0,0,0,2,0],
    [0,1,0,2,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0,0,0],
    [0,2,0,0,0,0,0,0,0,0],
    [0,0,3,0,0,2,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,2,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,1,0,0,2,3],
];

foreach($map as $r=>$row){
    print "<br>";
        foreach ($row as $c=>$col){        
            switch($col){ 
                case 0:?><a href="shoot.php?r=<?php print $r ?>&c=<?php print $c ?>"><img src='icons/water.png' ></a><?php ; break;
                case 1:?><a href="shoot.php?r=<?php print $r ?>&c=<?php print $c ?>"><img src="icons/ship.png"  ></a><?php ; break;
                case 2:?><a href="shoot.php?r=<?php print $r ?>&c=<?php print $c ?>"><img src="icons/miss.png"  ></a><?php ; break;
                case 3:?><a href="shoot.php?r=<?php print $r ?>&c=<?php print $c ?>"><img src="icons/explosion.png"></a><?php ; break;           
                default: print "wrong"; break;
            }
        }
};

///save to session
$_SESSION['map']=$map;

//ACASA se facut ca harta se se genereze automat 
?>
