<?php
//0-water
//1-ship
//2-miss
//3-hit YEEE
$map=[
    [3,1,0,0,0,0,0,0,0,0],
    [0,1,0,2,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0,0,0],
    [0,4,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
];

// 1- optimizare switch
// 2- for in for pe deasupra
?>
<?php  if($map[0][0]==0){ ?>
<img src="icons/water.png" >
<?php  } ?>
<?php  if($map[0][0]==1){ ?>
<img src="icons/ship.png" >
<?php  } ?>
<?php  if($map[0][0]==2){ ?>
<img src="icons/miss.png" >
<?php  } ?>
<?php  if($map[0][0]==0){ ?>
<img src="icons/explosion.png" >
<?php  } ?>