<?php
//0-water
//1-ship
//2-miss
//3-hit YEEE
$map=[
    [3,1,0,0,2,0,0,0,2,0],
    [0,1,0,2,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0,0,0],
    [0,2,0,0,0,0,0,0,0,0],
    [0,0,3,0,0,2,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,2,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,1,0,0,2,3],
];

for ($i=0; $i<count($map); $i++){
    print "<br>";
        foreach ($map[$i] as $j){        
            switch($j){ 
                case 0:?><img src='icons/water.png' ><?php ; break;
                case 1:?><img src="icons/ship.png"  ><?php ; break;
                case 2:?><img src="icons/miss.png"  ><?php ; break;
                case 3:?><img src="icons/explosion.png"><?php ; break;           
                default: print "wrong"; break;
            }
        }
};
?>
