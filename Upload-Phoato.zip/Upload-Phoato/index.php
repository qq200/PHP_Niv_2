<?php

// var_dump($_FILES);
////////////////////DESPRE MAPA///////////////
$folder_name=date("Y-m"); //generam denumirea mapii automat
    if(!file_exists("photos/$folder_name")){
        mkdir("photos/$folder_name"); //creaza mapa noua
}


////////////////////UPLOAD/////////////////
    if($_FILES["photo"]["type"]!="image/jpeg"){//daca formatul nu corespunde
        print "You can upload ONLY JPEG images";
    }else{
        $file_name=time();// numele failului in secunde din 1970
        move_uploaded_file($_FILES["photo"]["tmp_name"], //de unde luam
        "photos/$folder_name/$file_name.jpg");                //unde mutam/salvam
    }

//////////////////LIST PHOTO///////////////
$files=scandir("photos/$folder_name");
unset($files[0],$files[1]);
// var_dump($files);
foreach($files as $file){
    print"<img width='100' src='photos/$folder_name/$file'/><br/>";
}


// acasa: 1- sa nu apara la foaia goala eroare no index Foto
// 2 -de aratat ultimile 5 fotografii pe pagina
// 3-la printare sa se arate cele mai recente sus
// 4- de adaugat alaturi 
?>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="photo"> 
    <button>Upload</button>
</form>