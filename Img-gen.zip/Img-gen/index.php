<?php
//gd
//GET-parameters
//memory

// index.php?i=1&w500&H400
//////////////////GET user data
$i=$_GET['i']?? 1;
$w=$_GET['w']?? 400;
$h=$_GET['h']?? 300;
// print"$i,$w,$h";
?>
<form method="get">
    <h3>Choose image</h3>
    <label >
    <?php   for ($q=1; $q<=100; $q++ ){
                print "<img src='images/$q.jpeg' width='100' ><input type='checkbox' name='i' value='$q'>";                    
            }      
    ?>        
    </label>
    <h3>Choose width</h3>
    <label>
        <select name="w">
        <?php   for ($j=100; $j<=1000; $j+=100 ){
            print "<option>$j</option>";} 
        ?>
        </select>
    </label>
    <h3>Choose height</h3>
    <label>
        <select name="h">
        <?php  for ($j=100; $j<=1000; $j+=100 ){
            print "<option>$j</option>";} 
        ?>
        </select>
    </label>
    <button >Submit</button>
</form>
<?php
/////////////////////Process PHOTO
if(!file_exists("cache/$i--$w-x-$h.jpeg")){
    $original_image=imagecreatefromjpeg("images/$i.jpeg");
    $new_image=imagecreatetruecolor($w,$h);
    $size=getimagesize("images/$i.jpeg");
    // var_dump($size);
    // die();
    $ow=$size[0];
    $oh=$size[1];
    imagecopyresized(
        $new_image,
        $original_image,
        0,0,
        0,0,
        $w,$h,
        $ow,$oh);    //original dimensions
    imagejpeg($new_image,"cache/$i--$w-x-$h.jpeg", 65);
}
///////////////////Show to user
print"<a href='cache/$i--$w-x-$h.jpeg'>here is your image</a>";
?>
