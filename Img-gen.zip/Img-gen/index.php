<?php
//gd
//GET-parameters
//memory

// index.php?i=1&w500&H400
//////////////////GET user data
$i=$_GET['i']?? 1;
$w=$_GET['w']?? 400;
$h=$_GET['h']?? 300;
// print"$i,$w,$h";

/////////////////////Process PHOTO
if(!file_exists("cache/$i--$w-x-$h.jpeg")){
    $original_image=imagecreatefromjpeg("images/$i.jpeg");
    $new_image=imagecreatetruecolor($w,$h);
    $size=getimagesize("images/$i.jpeg");
    // var_dump($size);
    // die();
    $ow=$size[0];
    $oh=$size[1];
    imagecopyresized(
        $new_image,
        $original_image,
        0,0,
        0,0,
        $w,$h,
        $ow,$oh);    //original dimensions
    imagejpeg($new_image,"cache/$i--$w-x-$h.jpeg", 65);
}
///////////////////Show to user
print"<a href='cache/$i--$w-x-$h.jpeg'>here is your image</a>";
?>
<form method="get">
    <!-- ACASA -name=""->
</form>