<?php
for($i=1;$i<100; $i++){
    $data=file_get_contents("https://picsum.photos/id/$i/500/500");
    file_put_contents("images/$i.jpeg", $data);
    sleep(1); //pauza 1 sec
}


?>