<?php
// la click x la se faca close- se reduca nr <a>S


?>