<?php
session_start();

$v=$_SESSION['v']??1;


print "you've visits this page $v times!";

$_SESSION['v'] = ++$v; //aduna pe urma arata
?>