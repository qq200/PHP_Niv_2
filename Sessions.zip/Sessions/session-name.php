<?php
//inscrie numele utilizatorului in session
// phpinfo(); //session.save_path
session_start();
// $username='admin';
// // $_SESSION['user']=$username;
// $_SESSION['user']=[
//     'username'=>'admin',
//     'password'=>'12345',
//     'rating'=>4.5,
//     'date'=>'2019-05-24',
//     'online'=>true

// ]

print $_SESSION['user']['password'];

?>