<?php
session_start();
$allow=true;
const TIMEOUT =10;
//1- get dada from post
$username=$_POST['username']    ?? "";
$password=$_POST['password']    ?? "";
$confirm=$_POST['confirm']      ?? "";
$agree=$_POST['agree']          ?? "";
//2-TRIES
$n=$_SESSION['n']?? 1;
if(!empty($_POST)){    //verifica daca masivul POST e gol->nu a introdus nimic
    $_SESSION['n']=++$n;
}
//3- check tries
if($n>10){
    $now=time();
    $when=$_SESSION['when'] ?? 0;
    $_SESSION['when']=time();
    $allow=false;
    if($now-$when>=TIMEOUT){
        $allow=true;
        $_SESSION['n']=1;
    }       
}
?>
<?php if($allow){?>
<form method="POST">
    <label>
        <input name="username" type="text" placeholder="user name">
    </label>
    <br>
    <label>
        <input name="password" type="pasword" placeholder="pasword">
    </label>
    <br>
    <label>
        <input name="confirm" type="pasword" placeholder="confirm pasword">
    </label>
    <br>
    <label>
        <input name="agree" type="checkbox" > I agree with terms!
    </label>
    <hr>
    <button>REGISTER</button>

</form>
<?php } ?>
<?php if(!$allow){?>
    <div style="color:red;">
    Too many tries
    </div>
<?php } ?>


