<?php
const TMDB_API_KEY_V3='776f892c4a07af1c8ad181c0f7c02a6c';
const TMDB_API_URL_V3='https://api.themoviedb.org/3/';
const TMDB_API_IMG_V3='https://image.tmdb.org/t/p/w200';
const TMDB_API_KEY_V4='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3NzZmODkyYzRhMDdhZjFjOGFkMTgxYzBmN2MwMmE2YyIsInN1YiI6IjVjZmU3OGJiMGUwYTI2MmQ5MmNhYjQzNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.BsCJlFTclfkApsGWHxaxwnNY1svfkEk-eUEdnmhImUE';
const TMDB_API_URL_V4='https://api.themoviedb.org/4/';

?>