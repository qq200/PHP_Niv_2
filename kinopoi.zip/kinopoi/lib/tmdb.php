<?php
function get_populat_movies(){ //primeste masivul ce cele mai popilare filme
    if(!file_exists('data_cache/popular.ser')){
        $response=file_get_contents(TMDB_API_URL_V3.'movie/popular?api_key='.TMDB_API_KEY_V3);
        $data=json_decode($response, true);
        // var_dump($data);
        file_put_contents('data_cache/popular.ser', serialize($data));
    }else{
        $data=unserialize(file_get_contents('data_cache/popular.ser'));
    }
    
    return $data;
}
function get_genres(){ //primeste masivul ce cele mai popilare filme
    if(!file_exists('data_cache/genre.ser')){
        $response=file_get_contents(TMDB_API_URL_V3.'genre/movie/list?api_key='.TMDB_API_KEY_V3);
        $data=json_decode($response, true);
        // var_dump($data);
        file_put_contents('data_cache/genre.ser', serialize($data));
    }else{
        $data=unserialize(file_get_contents('data_cache/genre.ser'));
    }
    
    return $data;
}
function search_movies($phrase){ //primeste masivul ce cele mai popilare filme
    $phrase_cach=strtolower(trim($phrase));
    if(!file_exists("data_cache/$phrase_cach.ser")){
        $response=file_get_contents(TMDB_API_URL_V3.'search/movie?api_key='.TMDB_API_KEY_V3.'&query='.$phrase);
        $data=json_decode($response, true);
        // var_dump($data);
        file_put_contents("data_cache/$phrase_cach.ser", serialize($data));
    }else{
        ////de sus
    }
  
    
    return $data;
}

?>