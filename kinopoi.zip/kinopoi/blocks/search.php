<?php
$search=search_movies($_GET['q']);
?>

<form >
    <input name="q" type="text" placeholder="search here...">
    <button>Search</button>

</form>
<h2>Resultat</h2>
<ul>
<?php foreach($search['results'] as $result) {?>
<li>
<a href="#"><?php print $result['title']  ?></a>
</li>
<?php } ?>

</ul>