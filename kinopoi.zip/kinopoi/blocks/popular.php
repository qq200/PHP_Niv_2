<?php
$popular_movies=get_populat_movies();
//ACASA bootstrap carusel!!!!


?>
<div>
    <h2>Top 20 Popular Movies</h2>
    <ul>
    <?php foreach($popular_movies['results'] as $movie) {?>
        <li>
            <img src="<?php print TMDB_API_IMG_V3.$movie['poster_path']?>" >
            <h3><?php print $movie['title'] ?></h3>
               
        </li>
    
    <?php   } ?>
    </ul>
</div>