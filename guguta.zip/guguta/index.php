<?php
$data=unserialize(file_get_contents("data.ser"));

foreach ($data['blocks'] as $block){
    if(isset($block['h'])){
        print "<h1>{$block['h']}</h1>";
    }
    if(isset($block['p'])){
        print "<p>{$block['p']}</p>";
    }
}


?>