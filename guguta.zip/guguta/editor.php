<?php
session_start();

$title="edit this page";
$body=$_SESSION['body'] ?? '';

$action=$_GET['action']??'';
switch($action){
    case 'add_heading': $body.=include 'templates/heading-form.php'; break;
    case 'add_paragraph': $body.=include 'templates/paragraph-form.php'; break;
    case 'add_image': $body.=include 'templates/image-form.php'; break;
    case 'clear': session_destroy(); $body=''; break;
    case 'save': var_dump($_POST); file_put_contents("data.ser", serialize($_POST)); break;
}

$_SESSION['body']=$body;
$body="<form action=\"?action=save\" method=\"POST\">
        $body
      <button>Save</button>
      </form>";
?>



<?php
include 'templates/layout.php'


?>