<?php return "
    <div>
        <input name=\"blocks[][h]\" type=\"text\" placeholder=\"heading text\">


    </div>
"?>
