<?php return "

<div>
<input name=\"blocks[]\" type=\"file\">


</div>
"?>