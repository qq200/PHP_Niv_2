<?php return "
<div>
<textarea name=\"blocks[][p]\" placeholder=\"write text\"></textarea>


</div>
"?>