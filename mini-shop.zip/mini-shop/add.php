<?php
// adauga productele in cos
//scrim productele in sessie si redirectionam la index.php
session_start();
$pid=$_GET['pid'];
$_SESSION['cart'][]=$pid;
header("location: index.php");
?>