<?php
//sterge toate produsepe din cos
session_start();
session_destroy();
header("location: index.php");
?>