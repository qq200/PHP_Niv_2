<style>
body{
    margin:50px
}
div{
    clear: both; border: 1px solid #BBB; padding: 20px; overflow: hidden; margin: 5px;
}
img{
    float:left;
}
</style>
<?php include 'cart.php' //-copy/paste;  require-se difera ca nu indeplineste codul mai departe?> 
<hr>
<a href="?curr=EUR">EUR</a>
<a href="?curr=USD">USD</a>
<a href="?curr=MDL">MDL</a>
<hr>
<?php

$selected_currency=$_GET['curr'] ?? "MDL";
//   1-JSON-->array PHP
        //a-load file
        //b-decode json
$content=file_get_contents("./database/products.json");
$products=json_decode($content, true); //true pentru array format
// var_dump($products);

$content=file_get_contents("./database/currencies.json");
$currencies=json_decode($content, true); //true pentru array format
// var_dump($currencies);
//////////////////////PREPROCES//////(CURRENCY)/////////////
foreach($products as &$product){ ///////////////////////&-ia array original, il modifica
    $value=$product["price"]["value"];
    $curr= $product["price"]["currency"];

    $new_price=$value*$currencies[$curr][$selected_currency];
    // var_dump($new_price);
    $product["price"]["currency"]=$selected_currency; //modifica valuta selectata anterior
    $product["price"]["value"]=$new_price; //modifica valoarea primita in valuta setata
}
?>
<hr>
<?php foreach($products as &$product){?>

<div>
<img src="<?php print $product["photo"] ;?>"><small><?php print $product["price"]["value"]; print " ".$product["price"]["currency"];?></small>
<h2><?php print $product["name"]; ?></h2>
<a href="add.php?pid=<?php print $product["id"]; //transmite prin GET idul productului?>">Add to cart</a>
</div>
<?php } 
///ACASA 1- prin GD de facut lista de producte prin poze 200x200
///      2- de facut sa nu se repete produsele in cos
///      3- sortarea dupa pret -php multi sort!
//       4- form input +button"search"
//       5- item in cart: a href---->summary-> foreach (foto, name, price)

?>