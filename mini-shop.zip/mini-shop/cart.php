<?php
session_start();

$products_in_cart=$_SESSION['cart']??[];

if(count($products_in_cart)>0){
?>
<hr>
<h2>Items in cart: <?php print count($products_in_cart); ?>
<a href='clear.php'> x </a>
</h2>
<?php }else{?>
<h2>Cart is empty</h2>
<?php } ?>

<?php var_dump($products_in_cart);?>


